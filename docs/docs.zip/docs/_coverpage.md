# Minnosh <small>1.0.5</small>

> Personal & Lifestyle Blog.

- 10 + Different Layouts
- Light & Dark Versions
- 10 + Custom Shortcodes

[Get Support](http://thespan.ml/wordpress-themes/support/minnosh/)
[Buy The Theme](https://themeforest.net/item/minnosh-personal-lifestyle-blog/20757593?ref=TheSpan)
