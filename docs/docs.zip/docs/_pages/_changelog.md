# Update History

**Version 1.0.5**
 - Added WooCommerce Support
 - Update /languages/minnosh.pot

**Version 1.0.4**
 - Update demo data on minnosh-demo-importer plugin 
 - Improved Search icon control on Customizer panel 
 - Fixed Images hover opacity small issue

**Version 1.0.3**
 - Fixed Banner on Homepage small issue
 - Fixed Tabs posts active tab small issue

**Version 1.0.2**
 - Fixed carousel images load issue
 - Update Montserrat font settings
 - Added waitForImages.js

**Version 1.0.1**
 - Fixed small style issues
 - Fixed small script.js issue
 - Fixed small issue on one full post image
 
**Version 1.0.0**

- Initial release  
