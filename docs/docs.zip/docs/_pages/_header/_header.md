# Header

You can control the site header layout, style, background,... in **Customize > Header**.

## Header layouts

Minnosh support 5 header layouts. We call them as "Layout 1, Layout 2,... Layout 5". Just select the option Header Layout to change it.

- Option: General Header > Header Layouts
- Section: Appearance > Customize > Header > General Options

![Header Layouts](_media/header-layouts.jpg)