# Logo

You can change the logo image, select to use text logo, adjust margin,... in **Customize > Logo & Tagline**

## Change logo image

To change the logo image, you must ensure the option **Customize > Logo & Tagline > General Options**.
Upload your logo from **Logo Image** option

## Use text Logo

If you want to use text logo, Minnosh has options helping you design your text logo easily. Please follow these steps:

- Close Logo Image and Open Text Logo.
- Enter the text for your logo in option Text Logo.
- At last Go to **Customize > Logo & Tagline > Font Options** Select the favourite font variations for your logo. You can select font family, font weight, font size, letter spacing, text transform from Text Logo option.