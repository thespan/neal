# Upload Custom Fonts

In this section you can also upload custom fonts to the theme **Appearance > Custom Fonts**

![Custom fonts](_media/custom-fonts.jpg)