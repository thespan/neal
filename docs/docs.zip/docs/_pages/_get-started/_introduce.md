# Introduction

We would like to thank you for purchasing Minnosh! We are very pleased that you have chosen Minnosh for your website, you will not be disappointed! Before you get started, please be sure to always search our Documentation. We outline all kinds of good information, and provide you with all the details you need to use Minnosh. The theme can only be used with WordPress and we assume that you already have WordPress installed and ready to go. If you do not, please go to [wordpress.org](http://wordpress.org) to download and install the latest version of Wordpress. If you have any kind of theme related or presale questions, please ask it via commenting [THEME LINK](https://themeforest.net/item/minnosh-personal-lifestyle-blog/20757593/comments) or contact me at
**contact.thespan@gmail.com**

**Thank you again for purchasing this theme!**
