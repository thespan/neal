# Footer

You can control the site header layout, style, background,... in **Customize > Footer**.

## Footer layouts

Minnosh support 3 footer layouts. We call them as "Layout 1, Layout 2, Layout 3". Just select the option Footer Layout to change it.

- Option: General Footer > Footer Layouts
- Section: Appearance > Customize > Footer > General Options

![Footer Layouts](_media/footer-layouts.jpg)