# Instagram

You can show your Instagram images with **Owl Slider** or without Slider

- Option: General Header > Instagram
- Section: Appearance > Customize > Footer > General Options

![Setup Instagram](_media/setup-instagram.jpg)